/********************************************************************************
** Form generated from reading UI file 'fridgelogin.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRIDGELOGIN_H
#define UI_FRIDGELOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_fridgeLogin
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_6;
    QWidget *loginContainer;
    QVBoxLayout *verticalLayout_9;
    QWidget *emailWidget;
    QHBoxLayout *horizontalLayout_3;
    QLabel *emailText;
    QLineEdit *email_input;
    QWidget *passwordWidget;
    QHBoxLayout *horizontalLayout_4;
    QLabel *passwordText;
    QLineEdit *pass_input;
    QWidget *loginPushButtonWidget;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *exitButton;
    QPushButton *loginButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *fridgeLogin)
    {
        if (fridgeLogin->objectName().isEmpty())
            fridgeLogin->setObjectName("fridgeLogin");
        fridgeLogin->resize(667, 479);
        centralwidget = new QWidget(fridgeLogin);
        centralwidget->setObjectName("centralwidget");
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy);
        centralwidget->setMinimumSize(QSize(0, 0));
        centralwidget->setMaximumSize(QSize(1000, 1000));
        horizontalLayout_6 = new QHBoxLayout(centralwidget);
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        loginContainer = new QWidget(centralwidget);
        loginContainer->setObjectName("loginContainer");
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(loginContainer->sizePolicy().hasHeightForWidth());
        loginContainer->setSizePolicy(sizePolicy1);
        loginContainer->setMaximumSize(QSize(300, 16777215));
        verticalLayout_9 = new QVBoxLayout(loginContainer);
        verticalLayout_9->setObjectName("verticalLayout_9");
        emailWidget = new QWidget(loginContainer);
        emailWidget->setObjectName("emailWidget");
        horizontalLayout_3 = new QHBoxLayout(emailWidget);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        emailText = new QLabel(emailWidget);
        emailText->setObjectName("emailText");

        horizontalLayout_3->addWidget(emailText);

        email_input = new QLineEdit(emailWidget);
        email_input->setObjectName("email_input");
        email_input->setMaximumSize(QSize(160, 16777215));

        horizontalLayout_3->addWidget(email_input);


        verticalLayout_9->addWidget(emailWidget);

        passwordWidget = new QWidget(loginContainer);
        passwordWidget->setObjectName("passwordWidget");
        horizontalLayout_4 = new QHBoxLayout(passwordWidget);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        passwordText = new QLabel(passwordWidget);
        passwordText->setObjectName("passwordText");

        horizontalLayout_4->addWidget(passwordText);

        pass_input = new QLineEdit(passwordWidget);
        pass_input->setObjectName("pass_input");
        pass_input->setMaximumSize(QSize(160, 16777215));
        pass_input->setEchoMode(QLineEdit::Password);

        horizontalLayout_4->addWidget(pass_input);


        verticalLayout_9->addWidget(passwordWidget);

        loginPushButtonWidget = new QWidget(loginContainer);
        loginPushButtonWidget->setObjectName("loginPushButtonWidget");
        horizontalLayout_5 = new QHBoxLayout(loginPushButtonWidget);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        exitButton = new QPushButton(loginPushButtonWidget);
        exitButton->setObjectName("exitButton");
        sizePolicy.setHeightForWidth(exitButton->sizePolicy().hasHeightForWidth());
        exitButton->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(exitButton);

        loginButton = new QPushButton(loginPushButtonWidget);
        loginButton->setObjectName("loginButton");
        sizePolicy.setHeightForWidth(loginButton->sizePolicy().hasHeightForWidth());
        loginButton->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(loginButton);


        verticalLayout_9->addWidget(loginPushButtonWidget);


        horizontalLayout_6->addWidget(loginContainer);

        fridgeLogin->setCentralWidget(centralwidget);
        menubar = new QMenuBar(fridgeLogin);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 667, 22));
        fridgeLogin->setMenuBar(menubar);
        statusbar = new QStatusBar(fridgeLogin);
        statusbar->setObjectName("statusbar");
        fridgeLogin->setStatusBar(statusbar);

        retranslateUi(fridgeLogin);
        QObject::connect(exitButton, &QPushButton::clicked, fridgeLogin, qOverload<>(&QMainWindow::close));

        QMetaObject::connectSlotsByName(fridgeLogin);
    } // setupUi

    void retranslateUi(QMainWindow *fridgeLogin)
    {
        fridgeLogin->setWindowTitle(QCoreApplication::translate("fridgeLogin", "fridgeLogin", nullptr));
        emailText->setText(QCoreApplication::translate("fridgeLogin", "Email: ", nullptr));
        email_input->setPlaceholderText(QCoreApplication::translate("fridgeLogin", "Enter your email", nullptr));
        passwordText->setText(QCoreApplication::translate("fridgeLogin", "Password: ", nullptr));
        pass_input->setPlaceholderText(QCoreApplication::translate("fridgeLogin", "Enter your password", nullptr));
        exitButton->setText(QCoreApplication::translate("fridgeLogin", "Exit", nullptr));
        loginButton->setText(QCoreApplication::translate("fridgeLogin", "Login", nullptr));
    } // retranslateUi

};

namespace Ui {
    class fridgeLogin: public Ui_fridgeLogin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRIDGELOGIN_H
